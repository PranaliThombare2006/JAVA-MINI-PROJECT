public class NQueen {
    // Function to print the solution
    static void printSolution(int board[][]) {
        int N = board.length;
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                System.out.print(board[i][j] == 1 ? "Q " : ". ");
            }
            System.out.println();
        }
        System.out.println();
    }

    // Function to check if a queen can be placed on board[row][col]
    static boolean isSafe(int board[][], int row, int col) {
        int N = board.length;

        // Check this column on all previous rows
        for (int i = 0; i < row; i++) {
            if (board[i][col] == 1) {
                return false;
            }
        }

        // Check upper-left diagonal
        for (int i = row, j = col; i >= 0 && j >= 0; i--, j--) {
            if (board[i][j] == 1) {
                return false;
            }
        }

        // Check upper-right diagonal
        for (int i = row, j = col; i >= 0 && j < N; i--, j++) {
            if (board[i][j] == 1) {
                return false;
            }
        }
        return true;
    }

    // Function to solve N-Queen problem using backtracking
    static boolean solveNQueen(int board[][], int row) {
        int N = board.length;

        // If all queens are placed, return true
        if (row >= N) {
            return true;
        }

        // Try placing the queen in each column one by one
        for (int col = 0; col < N; col++) {
            if (isSafe(board, row, col)) {
                board[row][col] = 1; // Place queen

                // Recur to place the rest of the queens
                if (solveNQueen(board, row + 1)) {
                    return true;
                }
                // If placing queen in board[row][col] doesn't lead to a solution, backtrack
                board[row][col] = 0; // Remove queen (backtrack)
            }
        }
        return false; // If queen cannot be placed in any column
    }

    // Function to solve the N-Queen problem
    static void nQueen(int N) {
        int board[][] = new int[N][N]; // Create a board of size N x N

        // Initialize the board with 0 (empty cells)
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                board[i][j] = 0;
            }
        }

        // Try to solve the problem starting from the first row
        if (solveNQueen(board, 0)) {
            printSolution(board); // Print the solution
        } else {
            System.out.println("Solution does not exist.");
        }
    }

    public static void main(String[] args) {
        int N = 8; // Change this value to solve for different sizes of the board
        nQueen(N); // Call the function to solve the N-Queen problem
    }
}
